#include <iostream>
using namespace std;

int main() {
    int choice;
    double amount, total = 0;
    while (true) {
        cout << "\n1. Add Expense\n2. View Total\n3. Exit\nChoice: ";
        cin >> choice;
        if (choice == 1) {
            cout << "Enter amount: ";
            cin >> amount;
            total += amount;
        } else if (choice == 2) {
            cout << "Total Expenses: " << total << endl;
        } else {
            break;
        }
    }
    return 0;
}
