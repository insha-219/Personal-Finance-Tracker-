#include <iostream>
using namespace std;

int main() {
    cout << "Password Manager System" << endl;
    return 0;
}
