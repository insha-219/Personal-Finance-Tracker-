public class RestaurantBillingSystem {
    public static void main(String[] args) {
        System.out.println("Restaurant Billing System");
    }
}
