#include <iostream>
using namespace std;

int main() {
    cout << "Flight Booking System" << endl;
    return 0;
}
